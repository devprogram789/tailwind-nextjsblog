# -*- coding: utf-8 -*-
from fastapi import APIRouter
from firebase_admin import firestore
from firebase_admin import credentials, initialize_app
import json,requests




cred = credentials.Certificate({
  "type": "service_account",
  "project_id": "test-90c8f",
  "private_key_id": "2febed686509c01eaf12c5c2b629bec802b2c5bf",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDDmqxdBjo+xpm6\nu2/FCuMvrKekEjHb9vf48y1Isc8Yb0+2T+i7xGlKfqeVcCxqWy+ku0KaM8rkvmym\nSjfOsQqFX0o1rydTAkM+MdmLG/vtVPCSKvF3Gn98HsdL579g+c6NLfC7TdzHYxN3\nNgy6p4XfSwy5c0a/tScMfzKZNHDzyHuFYpNwnoWYsI5Vv0hAKhuvm/uDY2PVYNZJ\nDxmxv3bz2NQ1jcEEIujIDaPU7bDyl6h7wkocY7mHW/m9A6HckbYb6j1pP8nkDd1Z\nu/sgqH3czAO6nZ2ZC6vrsxJKa1v4UrfwjwvxfIZREWbICTQe+arYod/xAXrkDZGS\nIQgiWxA9AgMBAAECggEAC6qs0lfrVEW1CHPNY5ULPmjKT0lXiHgR9nBjWHqPMIpT\nwzsVFaf4zhJBAsiKmaW1MS/gddaWKNppHBUBVaEZJcyByQhuAcU43LDipGmyTHJR\nxAIZiLdU+G1UiUTkv7m+oGHnrHWlMA5LLFkrXVxdv4GthrJ8ZeBTQytOCbXHRpRT\n55c7vqdcyMjEos9kRlh5/hQrkxczSW11XYE6dp5ywuOpObLb4jrbkKmT0BQ7Evc/\nHfVUeKnMBuugqTJolEiim2dR4xeeAg+FWEZq+qldacKV9Fqsrtj42+7Nim0VmFoV\nZou40dfBFplSvFCTphyFhw1PsDHIef8euM8GjbDcgQKBgQD1aJCw+OCc2QPBix0N\nNVWgXsB+leU85QqvwcRmAb0qWXNvTtX9i7vQ3dtpw3MhJyJvM/kDCBHa1aicuFHo\n2GYlHFQD5JFpT/qr9x7NGFNH5NmJFmytA0CkjlllHGSfae/KT4uOg1HZqTN1jKBS\nBGnfvMn5Sv6iWO8RH2zy8B+/gQKBgQDMC9ZxDLdyKsm8aHt3E6pxAh2CcdPEplvl\nAcEfh2kAvJOiaCDo7lTNUaWQZyCqNSaYlYiIgAp2BPUNHpo3EELYRElYnbQ6CTtG\nOYzUG5j2TYXFc+Y2N6DWvlwNYeXsjJLfh2jQVSZOsj4BzaGcqksB7PTqDFZx+gcc\nzWG7J0GuvQKBgFuVvHnvR5QBgV9XlW36e4wwEFKtijGhoM1a2Prgp0IIxAXEPCQ1\nY9BdG6dq46p5umYZ1VKGTnOGzTg/qYHmUKiE2+3f/Ux6JqjKvtn3vAzWoUCB9+jR\nj+xZm48ae4rqtCyiZwi2hXNfq+6wnpw9PW3cPNwmWsUnv4B6Y+R+LLsBAoGBAK2f\n7QspPPfivOKbLWP30fJzUFTtMruEq3FEeuavPIQp8p4haM+L7ZEARpeHiV4L+Bmi\nNBmiikQ+l55gSe1M4vRPtvG2z+MKc+ufkNvz18bN1GRd6Kh90Viphn7ErPcJ7vhR\nqriLnBsexHCYX0qGBWlQDl8RvIUjseWqRd0Q3G0pAoGALXILrvym5KYETs/7Rdem\nCqR/IYNaM7CDYj1Vyu4BRp7CGG6cjOg60U4cm3ww+BAsvRdJ6Y0hvv5y5yL/AyJE\nVJA1a2B2cDZQ8UJrjDNc4CVAPr8YeQWV6Kz6xetT+uOVYeK38SADm+Fz18rD69Ao\n/F50DcAKVd/iiJDQBP6mNTg=\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-fmq1c@test-90c8f.iam.gserviceaccount.com",
  "client_id": "117959527322611278863",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fmq1c%40test-90c8f.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
})
default_app = initialize_app(cred)

dbx = firestore.client()
data_center_Ref = dbx.collection("data_center")
doc_all = data_center_Ref.get()
docs_listX = []
for doc in doc_all:
    docs_listX.append(doc.to_dict())
#print(docs_list)

router = APIRouter( tags=["FireBase"])
getreq = requests.get

DATABUU = json.loads(open('DataTemp/testData.json','r',encoding="UTF-8").read())

def JsonPrint(data):
    print(json.dumps(data, indent=4, sort_keys=True))

@router.get("/listfb")
def read_data():
    try:
        docs = data_center_Ref.stream()
        docs_list = []
        for doc in docs:
            docs_list.append(doc.to_dict())
        return json.dumps(docs_list), 200
    except Exception as error:
        return f"An Error Occured {error}"
    
@router.get("/doclistfb")
def list_doc():
    try:
        docs = data_center_Ref.list_documents()
        docs_listA = []
        for doc in docs:
            docs_listA.append(doc.id)
        return json.dumps(docs_listA)
    except Exception as error:
        return f"An Error Occured: {error}"
    

@router.get("/databuu")
def buu_data():
    try:
        return DATABUU
    except Exception as error:
        return f"An Error Occured: {error}"
